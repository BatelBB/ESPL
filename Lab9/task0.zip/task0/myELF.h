int getAction();

void toggleDebugMode();

void examineElfFile();

void printProgramHeaderStats();

void printSectionHeaderStats();

void printFIleOffset();

void printEntryPoint();

void printEncodingScheme();

void checkMagicNumbers();

void printMagicNumbers();

void loadFileToMap();

void unmapCUrrentFile();

void printSectionNames();

char *getSectionHeaderType(int num);

void printSymbols();

void RelocateTables();

void quit();
